LoadModule('jsstd');
LoadModule('jsio');
Print('Hello World\nPress Enter key to continue...');
File.stdin.Read();
